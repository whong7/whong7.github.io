//
//  DemoView.m
//  柱状图
//
//  Created by whong7 on 16/7/14.
//  Copyright © 2016年 whong7. All rights reserved.
//

#import "DemoView.h"
#import "UIColor+Addition.h"

@interface DemoView ()
@property (weak, nonatomic) IBOutlet UILabel *progressLabel;
@end

@implementation DemoView

-(void)setProgress:(CGFloat)progress
{
    _progress = progress;
    
    //在字符串中 如果想要使用百分号 调用 %%
    self.progressLabel.text = [NSString stringWithFormat:@"%.2f%%",progress*100];
    
    //只要用户给我新值，就要刷新
    [self setNeedsDisplay];
    
}

-(void)drawRect:(CGRect)rect
{
    //画扇形
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(150, 150) radius:100 startAngle:0-M_PI_2 endAngle:2*M_PI*self.progress-M_PI_2 clockwise:1];
    //画扇形 需要 往圆心连线
    [path addLineToPoint:CGPointMake(150, 150)];
    //上颜色
    [[UIColor randomColor]set];
    //渲染
    [path fill];
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{

}

@end
