//
//  ViewController.m
//  SizeClass 测试
//
//  Copyright © 2016年 吴鸿. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


//previousTraitCollection: 转动之前的SizeClass
- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection
{
    //NSLog(@"previousTraitCollection: %@", previousTraitCollection);
    
    //代码获取当前方法的SizeCalss变化 --> 目前的6S 高度会有R-->C的变化
    UIUserInterfaceSizeClass hSizeClass = self.traitCollection.verticalSizeClass;
    if (hSizeClass == UIUserInterfaceSizeClassCompact) {
        NSLog(@"横屏");
    } else {
        NSLog(@"竖屏");
    }
    
    NSLog(@"水平SizeClass: %zd", hSizeClass);
    
    //_UITraitNameHorizontalSizeClass: 宽度 --> w C
    //_UITraitNameVerticalSizeClass: 高度 --> h R
    /**
     <UITraitCollection: 0x6100000c78c0; _UITraitNameUserInterfaceIdiom = Phone, _UITraitNameDisplayScale = 2.000000, _UITraitNameDisplayGamut = sRGB, _UITraitNameHorizontalSizeClass = Compact, _UITraitNameVerticalSizeClass = Regular, _UITraitNameTouchLevel = 0, _UITraitNameInteractionModel = 1, _UITraitNameUserInterfaceStyle = 1, _UITraitNameLayoutDirection = 0, _UITraitNameForceTouchCapability = 2, _UITraitNamePreferredContentSizeCategory = UICTContentSizeCategoryL>
     */
}




@end
