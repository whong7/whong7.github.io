//
//  ViewController.h
//  SizeClass 测试
//
//  Copyright © 2016年 吴鸿. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

