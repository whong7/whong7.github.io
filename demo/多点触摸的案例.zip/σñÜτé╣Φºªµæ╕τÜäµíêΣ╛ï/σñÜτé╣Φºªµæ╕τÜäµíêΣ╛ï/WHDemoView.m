//
//  WHDemoView.m
//  多点触摸的案例
//
//  Created by whong7 on 16/7/11.
//  Copyright © 2016年 whong7. All rights reserved.
//

#import "WHDemoView.h"

@interface WHDemoView ()

@property(nonatomic,strong)NSArray *array;
@end

@implementation WHDemoView


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    
    self.array = @[@"spark_blue",@"spark_red"];
    [self addSpark:touches];
    
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self addSpark:touches];
}

-(void)addSpark:(NSSet<UITouch *> *)touches
{
    int i = 0;
    for (UITouch * t in touches) {//t是随机的
        
//        //获取出没对象
//        UITouch * t = touches.anyObject;
        //获取手指的位置
        CGPoint p =[t locationInView:self];
        //imageView
        UIImageView * imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:self.array[i]]];
        imageView.center = p;
        [self addSubview:imageView];
        
        
        [UIView animateWithDuration:2 animations:^{
            imageView.alpha = 0;
        } completion:^(BOOL finished) {
            [imageView removeFromSuperview];
        }];
        i++;
    }

}

@end
