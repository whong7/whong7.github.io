//
//  main.m
//  多点触摸的案例
//
//  Created by whong7 on 16/7/11.
//  Copyright © 2016年 whong7. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
