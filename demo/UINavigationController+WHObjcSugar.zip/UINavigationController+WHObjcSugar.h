//
//  UINavigationController+WHObjcSugar.h
//  UI-顶部放大
//
//  Created by 吴鸿 on 2016/11/10.
//  Copyright © 2016年 吴鸿. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (WHObjcSugar)

/// 自定义全屏拖拽返回手势
@property (nonatomic, strong, readonly) UIPanGestureRecognizer *wh_popGestureRecognizer;


@end
