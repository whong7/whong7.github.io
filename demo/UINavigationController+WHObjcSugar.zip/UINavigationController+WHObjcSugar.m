//
//  UINavigationController+WHObjcSugar.m
//  UI-顶部放大
//
//  Created by 吴鸿 on 2016/11/10.
//  Copyright © 2016年 吴鸿. All rights reserved.
//

#import "UINavigationController+WHObjcSugar.h"
#import <objc/runtime.h>

@interface WHFullScreenPopGestureRecognizerDelegate : NSObject <UIGestureRecognizerDelegate>

@property (nonatomic, weak) UINavigationController *navigationController;

@end

@implementation WHFullScreenPopGestureRecognizerDelegate

- (BOOL)gestureRecognizerShouldBegin:(UIPanGestureRecognizer *)gestureRecognizer {
    
    // 判断是否是根控制器，如果是，取消手势
    if (self.navigationController.viewControllers.count <= 1) {
        return NO;
    }
    
    // 如果正在转场动画，取消手势
    if ([[self.navigationController valueForKey:@"_isTransitioning"] boolValue]) {
        return NO;
    }
    
    // 判断手指移动方向
    CGPoint translation = [gestureRecognizer translationInView:gestureRecognizer.view];
    if (translation.x <= 0) {
        return NO;
    }
    
    return YES;
}

@end

@implementation UINavigationController (WHObjcSugar)

+ (void)load {
    
    Method originalMethod = class_getInstanceMethod([self class], @selector(pushViewController:animated:));
    Method swizzledMethod = class_getInstanceMethod([self class], @selector(wh_pushViewController:animated:));
    
    method_exchangeImplementations(originalMethod, swizzledMethod);
}

- (void)wh_pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    //判断 手势识别器 的view 上面是否含有我们自定义的手势
    if (![self.interactivePopGestureRecognizer.view.gestureRecognizers containsObject:self.wh_popGestureRecognizer]) {
        //如果没有添加 平移手势
        [self.interactivePopGestureRecognizer.view addGestureRecognizer:self.wh_popGestureRecognizer];
        //为平移手势 添加 监听者 和 执行方法，只替换手势，其他不变。
        
        //1.系统自带的手势是UIScreenEdgePanGestureRecognizer类型对象,屏幕边缘滑动手势
        //2.系统自带手势target是_UINavigationInteractiveTransition类型的对象
        //3.target调用的action方法名叫handleNavigationTransition:
        
        NSArray *targets = [self.interactivePopGestureRecognizer valueForKey:@"targets"];
        id internalTarget = [targets.firstObject valueForKey:@"target"];
        SEL internalAction = NSSelectorFromString(@"handleNavigationTransition:");
        // 什么时候调用：每次触发手势之前都会询问下代理，是否触发。// 作用：拦截手势触发
        self.wh_popGestureRecognizer.delegate = [self wh_fullScreenPopGestureRecognizerDelegate];
        [self.wh_popGestureRecognizer addTarget:internalTarget action:internalAction];
        
        // 禁用系统的交互手势
        self.interactivePopGestureRecognizer.enabled = NO;
    }
    
    //保险起见，如果当前控制器不是 导航控制器的 自控制器，就使用 “系统自带的方法”（交换过的）！
    if (![self.viewControllers containsObject:viewController]) {
        [self wh_pushViewController:viewController animated:animated];
    }
}

- (WHFullScreenPopGestureRecognizerDelegate *)wh_fullScreenPopGestureRecognizerDelegate {
    
    //_cmd在Objective-C的方法中表示当前方法的selector，正如同self表示当前方法调用的对象实例(补充在本文最下面)。
    WHFullScreenPopGestureRecognizerDelegate *delegate = objc_getAssociatedObject(self, _cmd);
    if (!delegate) {
        delegate = [[WHFullScreenPopGestureRecognizerDelegate alloc] init];
        delegate.navigationController = self;
        
        objc_setAssociatedObject(self, _cmd, delegate, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return delegate;
}

- (UIPanGestureRecognizer *)wh_popGestureRecognizer {
    //使用 动态添加属性 的方法，避免每次重新创建
    UIPanGestureRecognizer *panGestureRecognizer = objc_getAssociatedObject(self, _cmd);
    //如果对象 有这个属性，直接用；没有的话在进行创建
    if (panGestureRecognizer == nil) {
        panGestureRecognizer = [[UIPanGestureRecognizer alloc] init];
        panGestureRecognizer.maximumNumberOfTouches = 1;
        
        objc_setAssociatedObject(self, _cmd, panGestureRecognizer, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return panGestureRecognizer;
}

@end


//补充 _cmd 用法

/*
 _cmd在Objective-C的方法中表示当前方法的selector，正如同self表示当前方法调用的对象实例。
 
 1、
 //比如需要打印当前被调用的方法，可以在一个方法中添加：
 NSLog(@"%@ call",NSStringFromSelector(_cmd));
 
 2、
 还有一种用法是在runtime的时候，比如在某个分类方法里为对象动态添加属性，由于_cmd是在编译时候(compile-time)就已经确定的值，所以可以直接使用
 
 该用法取自于: forkingdog / UITableView-FDTemplateLayoutCell 中的用法
 
 由于objc_getAssociatedObject 和 objc_setAssociatedObject 第二个参数需要传入一个属性的键名，是 const void * 类型的，通常的做法是
 而使用_cmd可以直接使用该@selector的名称，即someCategoryMethod，并且能保证改名称不重复
 
 */




