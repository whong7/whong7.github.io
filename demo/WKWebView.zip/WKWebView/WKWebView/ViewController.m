//
//  ViewController.m
//  WKWebView
//
//  Created by 吴鸿 on 2016/10/26.
//  Copyright © 2016年 吴鸿. All rights reserved.
//

#import "ViewController.h"
@import WebKit;

@interface ViewController ()<WKNavigationDelegate,WKUIDelegate,UIGestureRecognizerDelegate>
@property (nonatomic)WKWebView *webView;

@end

@implementation ViewController

- (WKWebView *)webView {
    if (_webView == nil) {
        _webView = [[WKWebView alloc] initWithFrame:self.view.bounds];
        
        _webView.navigationDelegate = self;
        
        //拦截信息
        _webView.UIDelegate = self;
        
        //添加点击手势 需解决拦截棒
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapWebView:)];
        [_webView addGestureRecognizer:tap];
        tap.delegate = self;
        [_webView addGestureRecognizer:tap];
    }
    return _webView;
}

-(void)tapWebView:(UITapGestureRecognizer *)gesture{
    NSLog(@"%@",gesture);
    CGPoint point = [gesture locationInView:self.webView];
    
    NSString *js = [NSString stringWithFormat:@"wh_imageAourceFromPoint(%g,%g)",point.x,point.y];
    
    [self checkJsWithCompletion:^{
        //执行js
        [self.webView evaluateJavaScript:js completionHandler:^(id _Nullable result, NSError * _Nullable error) {
            NSLog(@"====>%@",result);
        }];
    }];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.webView];
    
    NSURL *url = [NSURL URLWithString:@"http://image.baidu.com"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [self.webView loadRequest:request];
    
}

#pragma mark - WKUIDelegate
//拦截 js 中的 alert
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler
{
    NSLog(@"%@",message);
    completionHandler();
}

//允许多个手势并发
#pragma mark - UIGestureRecognizerDelegate
-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}

#pragma mark - webview 代理方法
//截取网络访问请求
-(void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    NSLog(@"%@",navigationAction.request);
    //决定对请求的处理
    decisionHandler(WKNavigationActionPolicyAllow);
}

//完成导航
-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
   //注入 js
    NSLog(@"%@",[self jsString]);
    
    [webView evaluateJavaScript:[self jsString] completionHandler:^(id _Nullable result, NSError * _Nullable error) {
        NSLog(@"%@",result);
        
        [self checkJsWithCompletion:^{
            NSLog(@"js 注入成功");
        }];
    }];
}

//检验注入是否完成,获取js完成后续操作
- (void)checkJsWithCompletion:(void(^)())completion{
    NSString *js = @"typeof wh_imageAourceFromPoint;";
    [self.webView evaluateJavaScript:js completionHandler:^(id _Nullable result, NSError * _Nullable error) {
         NSLog(@"%@",result);
        
        if (error != nil) {
            NSLog(@"error");
            return ;
        }
        // 执行完成回调
        completion();
        
    }];
    
    
    
}

-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    
}

- (NSString *)jsString {
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"tools.js" withExtension:nil];
    return [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:NULL];
}

@end
